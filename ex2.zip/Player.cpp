//
// Name: Inbal Zelinger
// ID: 311247340
//
#include "Player.h"



Player::Player(char currentPlayer): sigh(currentPlayer) {}

Player::Player():sigh(' '){}

char Player::getSigh() {
    return this->sigh;
}












